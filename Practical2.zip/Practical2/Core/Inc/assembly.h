/*
 * assembly.h
 *
 */
 
#ifndef APPLICATION_USER_CORE_ASSEMBLER_H_
#define APPLICATION_USER_CORE_ASSEMBLER_H_
 
extern void ASM_Main(void);
 
#endif /* APPLICATION_USER_CORE_ASSEMBLER_H_ */
